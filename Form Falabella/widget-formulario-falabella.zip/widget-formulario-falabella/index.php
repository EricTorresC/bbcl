<?php

if(!empty($_POST)) {

	$error = false;
	$data = '';

	if(!empty($_POST['nombre']) && !empty($_POST['email']) && !empty($_POST['telefono']) && !empty($_POST['pregunta'])) {

		$_POST['email'] = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);

		if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) === false) {
		  	
		  	$_POST['nombre'] = filter_var($_POST['nombre'], FILTER_SANITIZE_STRING);
		  	$_POST['telefono'] = filter_var($_POST['telefono'], FILTER_SANITIZE_STRING);
		  	$_POST['pregunta'] = filter_var($_POST['pregunta'], FILTER_SANITIZE_STRING);

		  	if(!empty($_POST['nombre']) && !empty($_POST['telefono']) && !empty($_POST['pregunta'])) {
		  		$data = "Nombre: {$_POST['nombre']}; Telefono: {$_POST['telefono']}; E-mail: {$_POST['email']}; Pregunta: {$_POST['pregunta']}";
		  		file_put_contents("data.txt", $data, FILE_APPEND);
		  	}
		  	else {
			  	$error = true;
			}
		} 
		else {
		  	$error = true;
		}
	}
	else {
		$error = true;
	}
}

?>

<style type="text/css">
table td input, table td textarea {
	width: 100%;
}
.error {
	border: #ff0000 1px solid;
	margin-top: 5px;
	margin-bottom: 5px;
	padding: 5px;
}
.success {
	border: #00cc00 1px solid;
	margin-top: 5px;
	margin-bottom: 5px;
	padding: 5px;
}
</style>

<form action="./" method="post">
	<table>
		<tr>
			<td valign="top" align="left" width="30%">Nombre:</td>
			<td valign="top" align="left" width="70%"><input type="text" name="nombre" id="nombre" placeholder="Ingrese su nombre y apellido"></td>
		</tr>
		<tr>
			<td valign="top" align="left" width="30%">Teléfono:</td>
			<td valign="top" align="left" width="70%"><input type="text" name="telefono" id="telefono" placeholder="Ingrese su teléfono"></td>
		</tr>
		<tr>
			<td valign="top" align="left" width="30%">E-Mail:</td>
			<td valign="top" align="left" width="70%"><input type="email" name="email" id="email" placeholder="Ingrese su E-Mail"></td>
		</tr>
		<tr>
			<td valign="top" align="left" width="30%">Pregunta:</td>
			<td valign="top" align="left" width="70%"><textarea name="pregunta" id="pregunta" rows="5"></textarea></td>
		</tr>
		<tr>
			<td valign="top" align="left" width="30%"></td>
			<td valign="top" align="left" width="70%">
				<?php if(!empty($_POST)): ?>
					<?php if($error): ?>
						<div class="error">Ocurrió un error al enviar el <br />formulario, por favor intente <br />nuevamente.</div>
					<?php else: ?>
						<div class="success">Formulario enviado con éxito.</div>
					<?php endif; ?>
				<?php endif; ?>
				<input type="submit" value="Enviar">
			</td>
		</tr>
	</table>
</form>